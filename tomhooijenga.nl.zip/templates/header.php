<header>
    <img src="/assets/img/<?php echo $page->image; ?>"/>
    <h1>
        <a class="container-small" href="<?php echo $page->slug; ?>">
            <?php echo $page->title; ?>
        </a>
    </h1>
</header>