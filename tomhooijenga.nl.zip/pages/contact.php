<div class="container-small">
    <h1>Hello!</h1>

    <p>
        My name is Tom Hooijenga. JavaScript is my jam, but C# is cool too. Sometimes I work with PHP.
        I also like to tinker with (CSS) animations.
    </p>
    <p>
        Send me an email anytime.
        <a href="mailto:info@tomhooijenga.nl">info@tomhooijenga.nl</a>
    </p>
</div>
<canvas id="background"></canvas>
<script src="/assets/js/cool.js" async ></script>