<?php include 'pages' . DIRECTORY_SEPARATOR . $page->file; ?>
